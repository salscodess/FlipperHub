# Flipper-zero-files
flipper zero software and other cool things
